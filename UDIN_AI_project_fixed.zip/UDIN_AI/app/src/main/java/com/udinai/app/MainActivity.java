package com.udinai.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.ClipData;
import android.webkit.MimeTypeMap;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> uploadMessage;
    private final int darkBg = Color.rgb(15, 17, 22);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(17, 19, 24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(17, 19, 24));
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkBg);

        LinearLayout brandBar = new LinearLayout(this);
        brandBar.setGravity(Gravity.CENTER_VERTICAL);
        brandBar.setPadding(dp(18), 0, dp(18), 0);
        brandBar.setBackgroundColor(darkBg);
        TextView brand = new TextView(this);
        brand.setText("UDIN AI");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(19);
        brand.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        TextView tag = new TextView(this);
        tag.setText("  •  AI PHOTO EDITOR");
        tag.setTextColor(Color.rgb(80, 166, 255));
        tag.setTextSize(10);
        tag.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        brandBar.addView(brand);
        brandBar.addView(tag);
        root.addView(brandBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        webView = new WebView(this);
        webView.setBackgroundColor(darkBg);
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applyDarkTheme();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (uploadMessage != null) uploadMessage.onReceiveValue(null);
                uploadMessage = filePathCallback;
                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    if (fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception firstError) {
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                                fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                        startActivityForResult(Intent.createChooser(fallback, "Pilih file"), FILE_CHOOSER_REQUEST);
                    } catch (Exception secondError) {
                        if (uploadMessage != null) uploadMessage.onReceiveValue(null);
                        uploadMessage = null;
                        Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file.", Toast.LENGTH_LONG).show();
                        return false;
                    }
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                    String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) request.addRequestHeader("cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setTitle("UDIN AI - hasil gambar");
                    request.setDescription("Mengunduh hasil dari EzImage");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    String fileName = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                    if (fileName == null || fileName.trim().isEmpty()) {
                        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
                        fileName = "UDIN_AI_" + System.currentTimeMillis() +
                                (extension == null ? ".jpg" : "." + extension);
                    }
                    fileName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                    if (!fileName.contains(".")) {
                        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
                        if (extension != null) fileName += "." + extension;
                    }
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    request.setAllowedOverMetered(true);
                    request.setAllowedOverRoaming(true);
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                    Toast.makeText(MainActivity.this, "Download dimulai.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal memulai download.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl("https://ezimage.ai/");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void applyDarkTheme() {
        String css = "" +
            ":root{color-scheme:dark!important;background:#0f1116!important}" +
            "html,body{background:#0f1116!important;color:#e8eaf0!important}" +
            "body,main,section,article,header,footer,nav,aside,div,form{border-color:#292d38!important}" +
            "main,section,article,[class*=card],[class*=Card],[class*=panel],[class*=Panel],[class*=container],[class*=Container]{background-color:#171a22!important;color:#e8eaf0!important}" +
            "h1,h2,h3,h4,h5,h6,p,span,label,small,strong,li,a{color:#e8eaf0!important}" +
            "input,textarea,select,[contenteditable=true]{background:#20242e!important;color:#fff!important;border-color:#3a4050!important}" +
            "button{color:inherit!important}" +
            "[class*=upload],[class*=Upload],[class*=dropzone],[class*=Dropzone]{background:#1c202a!important;border-color:#41485a!important;color:#e8eaf0!important}" +
            "img,svg{filter:none!important}";
        String script = "(function(){var id='udin-ai-dark-theme';var old=document.getElementById(id);if(old)old.remove();var st=document.createElement('style');st.id=id;st.textContent=" +
                org.json.JSONObject.quote(css) + ";document.documentElement.appendChild(st);})();";
        webView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && uploadMessage != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            uploadMessage.onReceiveValue(results);
            uploadMessage = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (uploadMessage != null) uploadMessage.onReceiveValue(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
