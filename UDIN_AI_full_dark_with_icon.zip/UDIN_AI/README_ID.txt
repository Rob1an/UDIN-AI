UDIN AI - Android WebView wrapper for EzImage

Versi ini menambahkan:
- Bar merek UDIN AI di bagian atas aplikasi.
- Tema gelap pada tampilan halaman EzImage melalui CSS yang diinjeksi ke WebView.
- Status bar dan navigation bar gelap.
- Upload gambar, download hasil, JavaScript, DOM storage, dan tombol kembali.

Cara build melalui GitHub Actions:
1. Upload file UDIN_AI_project.zip ini ke repository GitHub (replace file lama).
2. Pastikan workflow .github/workflows/build-apk.yml yang ada di repository tetap memakai perintah:
   unzip -q UDIN_AI_project.zip
   gradle -p UDIN_AI assembleDebug
3. Buka tab Actions, pilih workflow Build UDIN AI APK, lalu Run workflow.
4. Jika selesai hijau, unduh artifact UDIN-AI-APK, ekstrak, lalu install app-debug.apk.

Catatan: tema gelap diterapkan pada elemen halaman EzImage dari sisi WebView. Jika EzImage mengubah struktur/stylesheet situsnya, beberapa elemen mungkin tetap memakai warna asli dan perlu penyesuaian CSS.
