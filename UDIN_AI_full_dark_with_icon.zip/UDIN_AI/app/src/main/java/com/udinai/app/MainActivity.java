package com.udinai.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> uploadMessage;
    private final int darkBg = Color.rgb(15, 17, 22);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(17, 19, 24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(17, 19, 24));
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkBg);

        LinearLayout brandBar = new LinearLayout(this);
        brandBar.setGravity(Gravity.CENTER_VERTICAL);
        brandBar.setPadding(dp(18), 0, dp(18), 0);
        brandBar.setBackgroundColor(darkBg);
        TextView brand = new TextView(this);
        brand.setText("UDIN AI");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(19);
        brand.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        TextView tag = new TextView(this);
        tag.setText("  •  AI PHOTO EDITOR");
        tag.setTextColor(Color.rgb(80, 166, 255));
        tag.setTextSize(10);
        tag.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        brandBar.addView(brand);
        brandBar.addView(tag);
        root.addView(brandBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        webView = new WebView(this);
        webView.setBackgroundColor(darkBg);
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applyDarkTheme();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (uploadMessage != null) uploadMessage.onReceiveValue(null);
                uploadMessage = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    uploadMessage = null;
                    Toast.makeText(MainActivity.this, "Tidak ada aplikasi pemilih file.", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                    String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) request.addRequestHeader("cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setTitle("UDIN AI - hasil gambar");
                    request.setDescription("Mengunduh hasil dari EzImage");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            "UDIN_AI_" + System.currentTimeMillis());
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                    Toast.makeText(MainActivity.this, "Download dimulai.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal memulai download.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl("https://ezimage.ai/");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void applyDarkTheme() {
        String css = "" +
            ":root{color-scheme:dark!important;background:#0b0d12!important}" +
            "html,body,#root,#__next,#__nuxt{background:#0b0d12!important;color:#edf0f6!important}" +
            "body{background:#0b0d12!important;color:#edf0f6!important}" +
            "*:not(img):not(video):not(canvas):not(svg):not(path):not(iframe){border-color:#303542!important}" +
            "header,footer,nav,main,section,article,aside,form,[role=dialog],[role=tabpanel]{background-color:#11151d!important;color:#edf0f6!important}" +
            "[class*=card],[class*=Card],[class*=panel],[class*=Panel],[class*=modal],[class*=Modal],[class*=container],[class*=Container],[class*=wrapper],[class*=Wrapper],[class*=upload],[class*=Upload],[class*=dropzone],[class*=Dropzone],[class*=editor],[class*=Editor]{background-color:#171c26!important;color:#edf0f6!important;border-color:#30394a!important}" +
            "h1,h2,h3,h4,h5,h6,p,span,label,small,strong,li,a,div{color:inherit!important}" +
            "a{color:#75aaff!important}" +
            "input,textarea,select,[contenteditable=true]{background:#202633!important;color:#fff!important;border:1px solid #3b465b!important;caret-color:#58a6ff!important}" +
            "input::placeholder,textarea::placeholder{color:#9aa5b5!important}" +
            "button,[role=button]{background-color:#202633!important;color:#f5f7fb!important;border-color:#3b465b!important}" +
            "button[type=submit],[class*=generate i],[class*=primary i]{background:#2563eb!important;color:#fff!important;border-color:#2563eb!important}" +
            "[style*=background-color\\:rgb(255],[style*=background-color\\:#fff],[style*=background-color\\:white]{background-color:#171c26!important}" +
            "[class*=purple i],[class*=violet i]{color:#8db8ff!important}" +
            "img,video,canvas,svg{filter:none!important}" +
            "::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-thumb{background:#394355;border-radius:8px}";
        String script = "(function(){" +
            "var id='udin-ai-dark-theme';" +
            "function install(){var root=document.documentElement;if(!root)return;var st=document.getElementById(id);if(!st){st=document.createElement('style');st.id=id;(document.head||root).appendChild(st);}st.textContent=" + org.json.JSONObject.quote(css) + ";}" +
            "install();" +
            "if(!window.__udinDarkObserver){window.__udinDarkObserver=new MutationObserver(function(){install();});window.__udinDarkObserver.observe(document.documentElement,{childList:true,subtree:true});}" +
            "})();";
        webView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && uploadMessage != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            uploadMessage.onReceiveValue(results);
            uploadMessage = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (uploadMessage != null) uploadMessage.onReceiveValue(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
