UDIN AI - Project Android WebView

Fitur:
- Membuka https://ezimage.ai/ di dalam aplikasi
- JavaScript dan penyimpanan web aktif agar fitur situs dapat berjalan
- Pemilih file untuk upload gambar
- Download hasil melalui Download Manager Android
- Tema dasar aplikasi gelap (status bar, navigation bar, latar belakang)

Cara membuat APK:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder UDIN_AI.
4. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh komponen build).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Ini project sumber Android, bukan APK yang sudah dikompilasi.
- Lingkungan pembuatan di sini tidak memiliki Android SDK/Gradle, jadi APK belum dapat dibangun langsung.
- Tampilan EzImage di dalam halaman tetap mengikuti desain situs; tema gelap diterapkan pada kerangka aplikasi Android.
- Fitur upload/download bergantung pada dukungan situs dan versi Android.


BUILD APK LEWAT HP (GitHub Actions):
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di https://github.com/new (nama: UDIN-AI, Public/Private bebas).
3. Upload ISI folder project ke repository dengan struktur folder yang sama, termasuk folder tersembunyi .github/workflows.
4. Buka tab Actions di repository, aktifkan Actions jika diminta.
5. Workflow "Build UDIN AI APK" akan berjalan setelah file masuk ke branch main. Bisa juga pilih workflow lalu Run workflow.
6. Setelah selesai (centang hijau), buka hasil run dan unduh artifact "UDIN-AI-debug-APK".
7. Ekstrak artifact ZIP untuk mendapatkan app-debug.apk, lalu instal di HP.

Penting: APK debug ini untuk instalasi pribadi/testing. Saat instalasi Android mungkin meminta izin "Install unknown apps".
